Youtube: https://www.youtube.com/shorts/ns76gwlg5kY

Facebook: https://www.facebook.com/reel/1684733128669502

Tiktok: https://www.tiktok.com/@banlinhkienretail/video/7286084664836492545?lang=vi-VN