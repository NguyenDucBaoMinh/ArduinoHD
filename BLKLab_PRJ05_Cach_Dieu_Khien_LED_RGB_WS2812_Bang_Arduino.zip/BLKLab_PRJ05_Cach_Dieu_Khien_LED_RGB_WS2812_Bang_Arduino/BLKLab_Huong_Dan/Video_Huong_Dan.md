Youtube: https://www.youtube.com/shorts/LHUeNkfGrt4

Facebook: https://www.facebook.com/reel/1338983507039292

Tiktok: https://www.tiktok.com/@banlinhkienretail/video/7276639623617498370?lang=vi-VN