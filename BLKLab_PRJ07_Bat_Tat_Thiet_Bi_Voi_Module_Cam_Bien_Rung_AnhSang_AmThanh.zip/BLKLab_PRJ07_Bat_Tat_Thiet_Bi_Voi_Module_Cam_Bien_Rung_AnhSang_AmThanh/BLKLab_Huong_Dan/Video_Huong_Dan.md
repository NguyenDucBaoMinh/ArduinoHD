Tiktok: https://www.tiktok.com/@banlinhkienretail/video/7224118394122030342?lang=vi-VN

Facebook: https://www.facebook.com/reel/552401387034845

Youtube: https://www.youtube.com/shorts/gAcF9GxkFPM