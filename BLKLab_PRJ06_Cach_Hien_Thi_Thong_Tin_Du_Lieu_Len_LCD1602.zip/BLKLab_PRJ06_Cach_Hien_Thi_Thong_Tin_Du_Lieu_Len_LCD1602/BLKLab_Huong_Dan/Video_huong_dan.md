Youtube: https://www.youtube.com/shorts/4kUr1YKePUM

Tiktok: https://www.tiktok.com/@banlinhkienretail/video/7270699295504895240?lang=vi-VN

	https://www.tiktok.com/@banlinhkienretail/video/7419512319459249415

Facebook: https://www.facebook.com/reel/702340381728748